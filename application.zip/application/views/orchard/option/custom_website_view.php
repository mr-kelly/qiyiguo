<?php
	$this->load->view('garden/garden_header_view');
?>

afds

<?php
	$this->load->view('garden/garden_footer_view');
?>