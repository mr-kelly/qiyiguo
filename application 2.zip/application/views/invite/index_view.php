<?php
	$this->load->view('header_view');
?>

	<div id="content">
		<div class="content_top">
			<div class="content_bottom">
				
				<h2>邀请MSN好友</h2>
				
				<h2>发一条微博</h2>
				<div>
					点击~
					<a href="<?=site_url('invite/t_sina');?>" class="kk_btn">
						微博通知
					</a>
				</div>
				
				<h2>选择微博好友</h2>
				
				
				
				
				
			</div>
		</div>
	</div>


<?php
	$this->load->view('footer_view');
?>