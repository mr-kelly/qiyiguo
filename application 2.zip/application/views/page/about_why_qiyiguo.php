
<?php
	$this->load->view('header_view');
?>

	<div id="content">
		<div class="content_top">
			<div class="content_bottom">
				<h1>为什么叫奇异果?</h2>
				<p>
					我们并不介意你将奇异果称呼为“猕猴桃”。
				</p>
			</div>
		</div>
	</div>

<?php
	$this->load->view('footer_view');
?>