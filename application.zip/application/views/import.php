    
    <? // jQuery ?>
    <?=import_js('js/lib/lib.js');?>
    <?=import_js('js/css_fixed.js');?>
    

   
    <? // jQuery UI ?>
    <?php
    /*
    <script type="text/javascript" src="<?=static_url();?>js/ui/js/jquery-ui-1.8.4.min.js"></script> 
    <link rel="stylesheet" type="text/css" media="all" href="<?=static_url();?>js/ui/css/cupertino/jquery-ui-1.8.4.css" />
    <!--<link rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.7.2/themes/cupertino/jquery-ui.css" type="text/css" />-->
    */
    ?>
   
    <? // CSS ?>
    <?=import_css('css/base.css');?>
    <?=import_css('css/html.css');?>
    <?=import_css('css/decorator.css');?>
    <?=import_css('css/style.css');?>
	<?=import_css('css/kk_tabs.css');?>
	<?=import_css('css/kk_table.css');?>
	<?=import_css('css/kk_pagination.css');?>
	
	<?php // CKEditor ?>
	<? //import_js('js/ckeditor/ckeditor_basic.js');?>
	<? //import_js('ckeditor/adapters/jquery.js');?>
	

	<? // jQuery Form ?>
	<?=import_js('js/kk.form.js');?>
	
	<? //jQuery input tips ?>
	<?=import_js('js/kk.input_tips.js');?>
		
	<? // jQuery jSCroll 滚动条 ?>
	<?=import_js('js/kk.jscroll.js');?>
	
	<? // jQuery iframe auto height ?>
	<?=import_js('js/kk.iframeAutoHeight.js');?>
	
	<? // jQueryr pozFixed Position Fixed ?>
	<?=import_js('js/kk.pozFixed.js');?>

	<? // jQueryr Center ?>
	<?=import_js('js/kk.center.js');?>
	
	<!-- jGrowl-->
	<script type="text/javascript" src="<?=static_url('js/jGrowl/jquery.jgrowl.js');?>"></script>
	<link href="<?=static_url('js/jGrowl/jquery.jgrowl.css');?>" type="text/css" rel="stylesheet" />
	
	
	
	<? // jQuery Tipsy ?>
	<?=import_js('js/tipsy/kk.tipsy.js');?>
	<?=import_css('js/tipsy/tipsy.css');?>
	
	<!-- jQuery Fancybox-->
	<?=import_js('js/fancybox/kk.easing-1.3.pack.js');?>
	<?=import_js('js/fancybox/kk.mousewheel-3.0.4.pack.js');?>
	
	<?=import_js('js/fancybox/kk.fancybox-1.3.4.pack.js');?>
	<?=import_css('js/fancybox/kk.fancybox-1.3.4.css');?>
	
	<? // jQuery Validation ?>
	<?=import_js('js/kk.validate.js');?>
	<?=import_js('js/kk.validate.messages_cn.js');?>
	
	<!--jQuery idTabs-->
	<?=import_js('js/kk.idTabs.min.js');?>
	
	<? // jQuery Sticky Scroller ?>
	<? //import_js('js/StickyScroller.min.js');?>
	<? //import_js('js/GetSet.js');?>
	
	<? // jQuery png Fix for IE6 ?>
	<?=import_js('js/kk.pngFix.pack.js');?>
	
	<?=import_js('js/global.js');?>
	
	
	<? // 简繁转换 ?>
	<?=import_js('js/tw_cn.js');?>
	

