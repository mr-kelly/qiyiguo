<?php $this->load->view('header_view'); ?>

	<div id="content">
		<div class="content_top">
			<div class="content_bottom">
				<h1>高级功能</h1>
			</div>
		</div>
	</div>

<?php $this->load->view('footer_view'); ?>