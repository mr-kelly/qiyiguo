<?php
	// 判断用户是否已登录，并且判断是否是站点总管理员
	function is_site_admin() {
		
	}