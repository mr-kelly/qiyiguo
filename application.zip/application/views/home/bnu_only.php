<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
	"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8">
	<title>奇异果 - 发现并创造你的生活</title>
	<meta name="generator" content="BBEdit 9.6">
	<style>
		body {
			font-size: 12px;
		}
	</style>
</head>
<body style="text-algin:center">
	<div style="text-align:center;width:650px;margin: 50px auto;">
		<img src="<?=static_url('img/login_forbidden.png');?>" />
		
		<br /><br /><br /><br />
		<a href="http://qiyiguo.cc">
			&copy; 某人
		</a>
	</div>
	
	<div>
		
	</div>
</body>
</html>
