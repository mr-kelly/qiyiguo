<?php
	$this->load->view('general/general_header_view');
?>



<?php
	$this->load->view('general/general_footer_view');
?>