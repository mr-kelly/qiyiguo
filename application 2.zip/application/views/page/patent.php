<?php
	$this->load->view('header_view');
?>

	<div id="content">
		<div class="content_top">
			<div class="content_bottom">
				<h1>专利版权保护</h1>
				
			</div>
		</div>
	</div>


<?php
	$this->load->view('footer_view');
?>
