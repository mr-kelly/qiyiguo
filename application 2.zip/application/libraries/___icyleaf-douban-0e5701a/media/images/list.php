http://t.douban.com/icon/user.jpg

http://t.douban.com/pics/book-default-small.gif
http://t.douban.com/pics/music-default-small.gif
http://t.douban.com/pics/movie-default-small.gif

http://t.douban.com/pics/book-default-medium.gif
http://t.douban.com/pics/music-default-medium.gif
http://t.douban.com/pics/movie-default-medium.gif

http://t.douban.com/pics/icon/host_small.gif
http://t.douban.com/pics/icon/host_big.gif

http://t.douban.com/pics/icon/system_9px.gif		=> system.gif

http://t.douban.com/pics/event/mpic/event_dft.jpg	=> event-default-medium.jpg
http://t.douban.com/pics/event/bpic/event_dft.jpg	=> event-default-small.jpg

http://t.douban.com/pics/stars.gif

===========
repeat.png,  reply.png, dm.png picked from dabr.
===========