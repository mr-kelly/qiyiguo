<?php
	$this->load->view('orchard/orchard_header_view');
?>

<div id="content">
	<h2>奇异果果园 - 后台管理</h2>
</div>


<?php
	$this->load->view('orchard/orchard_footer_view');
?>