<?php
	$this->load->view('header_view');
?>

	<div id="content">
		<div class="content_top">
			<div class="content_bottom">
				<h1>实验室 - 人才招募</h1>
				<p>
					我们对产品疯狂的专注，应用创新。
					产品人是核心，产品为导向
				</p>
				
				
				
			</div>
		</div>
	</div>

<?php
	$this->load->view('footer_view');
?>