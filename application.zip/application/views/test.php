
				<form method="post" action="/kiwiguo/chat/add/group/17">
					<input type="text" name="chat_title" />
					<input type="text" name="chat_content" />
					<input type="hidden" name="chat_parent_id" value="0"/>
					
					<input type="submit" />
				</form>
