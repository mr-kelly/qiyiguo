<?php

/**
 * @file
 * A single location to store configuration.
 */

define('CONSUMER_KEY', 'ELi0Wc1kMAuJyHJQ68AEg');
define('CONSUMER_SECRET', 'Vkf6oqNnckF3Tlf00BVzQkMYmcx8mkkI7MzpXixsjY');
define('OAUTH_CALLBACK', 'http://local.dev/twitteroauth/callback.php');
