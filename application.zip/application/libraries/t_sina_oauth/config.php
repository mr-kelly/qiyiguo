<?php
define( "WB_AKEY" , '3605840884' );
define( "WB_SKEY" , 'e73a5c46c8c9cdb8eb1b756f084becc8' );

?>