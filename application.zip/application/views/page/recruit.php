
<?php
	$this->load->view('header_view');
?>

	<div id="content">
		<div class="content_top">
			<div class="content_bottom">
				<h1>活出你的未来 - 在奇异果</h2>
				<p>试试说出这样的一句话？ “我，来自奇异果”，他蕴含了什么?</p>
				<h2>数据挖掘工程师</h2>
				<p>aaa</p>
				<ul>
					<li>求真务实</li>
					<li>相信技术、相信算法能够改变生活</li>
					<li>MySQL</li>
					
				</ul>
				
				
				<h2>软件工程师</h2>
				
				<h2>前端工程师</h2>
				
				<h2>产品经理</h2>
				
				<h2>移动产品经理</h2>
				
				<h2>公关关系经理</h2>
				
				
			</div>
		</div>
	</div>

<?php
	$this->load->view('footer_view');
?>