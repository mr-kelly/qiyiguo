<?php
	$this->load->view('general/general_header_view');
?>
<script>
	
	window.returnValue="http://www.51js.com";
	//window.close();
	
</script>

<?php
	$this->load->view('general/general_footer_view');
?>