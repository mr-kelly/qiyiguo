<?php
	$this->load->view('header_view');
?>

	<div id="content">
		<div class="content_top">
			<div class="cotnent_bottom">
				我的群话题
			</div>
		</div>
	</div>

<?php
	$this->load->view('footer_view');
?>