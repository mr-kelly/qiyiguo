				<div class="sidebar_widget align_center">
					<br /><br />
					<script type="text/javascript"><!--
					google_ad_client = "pub-9928587148743461";
					/* on kiwiguo.net */
					google_ad_slot = "3982629330";
					google_ad_width = 200;
					google_ad_height = 200;
					//-->
					</script>
					<script type="text/javascript"
					src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
					</script>
				</div>