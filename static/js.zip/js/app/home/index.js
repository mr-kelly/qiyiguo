function home_intro_show() {
	$('#home_intro').fadeIn(2000);
}

$(function(){
	// 2秒后出现介绍
	setInterval('home_intro_show()', 1000);
	
	$('#user_login_login').focus();
});

