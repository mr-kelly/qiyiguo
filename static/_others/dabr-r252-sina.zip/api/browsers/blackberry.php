<?php

function blackberry_theme_avatar($url, $force_large = false) {
  return "<img src='$url' />";
}

?>